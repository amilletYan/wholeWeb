
var data = [
	{href : 'http://fy.035k.com',text : '我的博客http://fy.035k.com'},
	{href : 'http://www.baidu.com',text : '百度'},
	{href : 'http://www.17sucai.com',text : 'jquery插件网'},
	{href : '',text : '苏打绿可根据历史'},
	{href : '',text : '管理数据管理'},
	{href : '',text : '另外今年光缆和并购水晶宫老师'}
]
